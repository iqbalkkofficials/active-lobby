import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { CityDetailComponent } from './city-detail/city-detail.component';
import { MatTableModule } from '@angular/material/table';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from "@angular/material/select";

@NgModule({
  declarations: [HomeComponent, CityDetailComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    MatSelectModule,
    // Material Modules for Datatable, List and Buttons
    MatTableModule,
    MatListModule,
    MatButtonModule,
    MatPaginatorModule
  ]
})
export class HomeModule { }
