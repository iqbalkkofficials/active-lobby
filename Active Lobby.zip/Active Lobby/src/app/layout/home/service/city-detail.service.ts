import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class CityDetailService {
  constructor(public http: HttpClient) { }
  
  // retreiving list of countries
  getCountries(){
    return this.http.get('assets/weather.json');
  }

   // retreiving data for listing in table
   getWeatherDetail(name) {
    return this.http.get('http://api.openweathermap.org/data/2.5/weather?q='+name+'&appid=dedc01318e234a027c967927ef95e3ee');
  }
}
