import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class CityDetailService {
  url = 'api.openweathermap.org/data/2.5/weather/q=Taglag&appid=dedc01318e234a027c967927ef95e3ee';
  constructor(public http: HttpClient) { }
  

   // retreiving data for listing in table
   getWeatherDetail() {
    return this.http.get(`${this.url}`);
  }
}
