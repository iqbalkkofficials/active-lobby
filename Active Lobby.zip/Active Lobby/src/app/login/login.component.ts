import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    loginForm : FormGroup;
    submitted = false;
    userName : string;
    passWord : string;
    constructor(private router: Router,private fb:FormBuilder,private _snackBar:MatSnackBar) {
        this.loginForm = this.fb.group({
            username: ["", Validators.required],
            password: ["", Validators.required],
          });
    }

    ngOnInit() {}

    get f() {
        return this.loginForm.controls;
    }

    // function to login
    onLogin() {
        this.userName=localStorage.getItem('username');
        this.passWord=localStorage.getItem('password');
        this.submitted = true;
        if(!this.loginForm.valid){
            return;
        }
        if((this.loginForm.value.username == this.userName) && (this.loginForm.value.password == this.passWord)){
            localStorage.setItem('isLoggedin', 'true');
            this.router.navigate(['/homepage']);
        }
        else
        { 
            const msg = "Invalid username or password";
            this._snackBar.open(msg, "", {
                duration: 2500,
                verticalPosition: "bottom",
            });  
        }
    }
}
