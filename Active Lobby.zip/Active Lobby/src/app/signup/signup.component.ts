import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatSnackBar } from "@angular/material/snack-bar";

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signupForm : FormGroup;
  submitted = false;
  constructor(private router: Router, private fb: FormBuilder, private _snackBar : MatSnackBar) { 
    this.signupForm = this.fb.group({
      firstname: ["", Validators.required],
      lastname: [""],
      phone: ["", Validators.required],
      email: ["", Validators.required],
      username: ["", Validators.required],
      password: ["", Validators.required],
    });
  }

  ngOnInit(): void {
  }

  get f() {
    return this.signupForm.controls;
  }

  signup() {
    this.submitted = true;
    // const userData = {
    //   "First name" : this.signupForm.value.firstname,
    //   "Last name" : this.signupForm.value.lastname,
    //   "Phone number" : this.signupForm.value.phone,
    //   "Email" : this.signupForm.value.email,
    //   "Username" : this.signupForm.value.username,
    //   "Password" : this.signupForm.value.password 
    // }
   // localStorage.setItem('isLoggedin', 'true');
   if(this.signupForm.valid)
      {
      localStorage.setItem("first name",this.signupForm.value.firstname);
      localStorage.setItem("last name",this.signupForm.value.lastname);
      localStorage.setItem("phone number",this.signupForm.value.phone);
      localStorage.setItem("email",this.signupForm.value.email);
      localStorage.setItem("username",this.signupForm.value.username);
      localStorage.setItem("password",this.signupForm.value.password);
      const msg = "Registered Successfully";
            this._snackBar.open(msg, "", {
                duration: 2500,
                verticalPosition: "bottom",
            }); 
      this.router.navigate(['/login']);
      }
}
}
