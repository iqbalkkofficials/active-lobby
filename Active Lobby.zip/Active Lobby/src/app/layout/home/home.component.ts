import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  firstname:string;
  lastname:string;
  phone:string;
  email:string;
  username:string;
  constructor() { }

  ngOnInit(): void {
    this.userDetail();
  }

  userDetail(){
    this.firstname = localStorage.getItem('first name');
    this.lastname = localStorage.getItem('last name');
    this.phone = localStorage.getItem('phone number');
    this.email = localStorage.getItem('email');
    this.username = localStorage.getItem('username');
  }
}
